# FingVibe reference

[Back to the README](../README.md) · [Contributing](../CONTRIBUTING.md)

Detailed usage, limitations, persistence, build identity, and contributor checks.
For the optional internet speed test, see [Cloudflare speed test](speed-test.md).
The desktop interface is native WinUI 3; WebView2 is restricted to the local
Cloudflare speed-test host. Tools uses matching 48-DIP Segoe Fluent icons beside
the names inside its existing landing buttons and beside individual page titles:
a speedometer for Speed test, a repair wrench for Network troubleshooting, an
information symbol for About FingVibe, and an import arrow for Import from Fing.
The icons follow the theme's primary text color, including Windows high contrast;
titles wrap at narrow widths. Icons are decorative, so button names and keyboard
navigation remain unchanged. Each individual tool places its secondary
**← Tools** action at the right of the title row, vertically centered with the
heading. **Run checks** and **Start test** use the same accent-button styling;
**Import all** retains its existing emphasis. Supporting actions stay neutral.

- [Run locally and scan behavior](#run-locally)
- [Device identification](#device-identification)
- [People and rooms](#people-and-rooms)
- [Inventory and Fing import](#inventory-and-fing-import)
- [Tests](#test)
- [Download builds](#download-builds)
- [Pull request review gates](#pull-request-review-gates)

## Run locally

Prerequisites:

- Windows 11
- .NET 8 SDK
- Visual Studio 2022 with the **Windows application development** workload, or the equivalent Windows SDK build tools

```powershell
dotnet restore FingVibe.sln
dotnet run --project src\FingVibe.App\FingVibe.App.csproj -p:Platform=x64
```

The scanner uses ICMP echo requests. Firewall rules and devices configured not to answer ICMP can prevent an active device from appearing in the results. On first use, vendor detection downloads the official IEEE MA-L, MA-M, and MA-S registries and caches them under the current user's local application data for 30 days.

Overview shows the selected interface as the network name, with subnet and available ISP information beneath it. Every page shares a compact header with the **Detected network** label, network picker, and displayed-scan freshness on one vertically aligned row; narrow windows stack these elements without hiding them. Scan actions remain below the row, and longer scan messages, target warnings, and errors appear beneath the actions. The freshness indicator describes the displayed scan, not continuous monitoring, and refreshes periodically. Displayed results retain their subnet and observation time; selecting another network explicitly identifies results from a different scan target. Cancel and progress appear only during a scan. The 6-DIP progress line retains measured determinate progress, with a repeating color pulse traveling only through the completed portion. The pulse stops on completion, cancellation, or failure; Windows animation preferences and high contrast use a static indicator instead. Before the first scan, Overview provides guidance rather than unknown counts.

Select the online-device or open-port summary card to open the corresponding Devices results. This clears stale search/summary filters; the visible **With open ports** checkbox can be cleared to return to other devices and combines with text search and People/Rooms filters. Open ports describe observed services, not a security verdict. Overview does not count unused addresses as offline devices. Inventory retains local observations, not an event timeline. The compact **About FingVibe** card opens **Tools > About FingVibe** directly. About is also available from the Tools landing page and contains version/build details and links to the repository and creator's website (opened in the external browser).

The running version is visible near the top of Overview and in the window title. Official release builds have no ribbon. PR artifacts show their PR number and an amber diagonal **TEST BUILD** ribbon; local builds show **DEV**, and manually dispatched non-PR CI builds show **TEST**. A smaller second line visibly shows the UTC build date/time (for example, **Built Nov 1, 12:20 UTC**). The tooltip and About show the full timestamp, including year and seconds, and commit information when recorded. Click or keyboard-activate the ribbon to acknowledge it until the app closes. The title and About details retain the build identity after acknowledgment. The ribbon floats above the page at the top-right client-area corner below the unchanged native title bar, extending continuously to the top and right edges. The header keeps a consistent right-hand clearance in every build, so showing or acknowledging the ribbon never shifts or resizes page content. The ribbon uses system colors in Windows high contrast.

Build identity is stamped into assembly metadata using `BuildKind` (`Release`, `PullRequest`, `Test`, or `Development`), `PullRequestNumber`, `BuildCommit`, `BuildUrl`, and `BuildTimestamp`. The CI and release workflows set these alongside the numeric `Version`; local builds default to `Development`, even when compiled with the Release configuration. `BuildTimestamp` defaults to the actual UTC build time in invariant ISO 8601 round-trip format (`yyyy-MM-ddTHH:mm:ss.fffffffZ`); CI and release workflows supply the same UTC format at second precision. To preserve an artifact's identity for repeatable builds, explicitly supply `-p:BuildTimestamp=2026-11-01T12:20:35Z` (or `/property:BuildTimestamp=...` with MSBuild). The override is preserved verbatim; parsing accepts zero to seven fractional-second digits before `Z`. Timestamps without an explicit UTC `Z` are invalid. Missing or malformed timestamps visibly show **Build time unavailable**, and malformed metadata emits a trace diagnostic; executable dates and launch time are never used. About shows PR and GitHub Actions run links when available. Unknown build kinds remain visibly non-release, and missing version metadata is displayed as unavailable rather than as an official version.

`tests\BuildIdentity.Ui.Tests.ps1 -AppPath <published-exe> -Version <numeric-version> -BuildKind <kind> -BuildTimestamp <stamped-UTC-time> -BuildCommit <commit>` checks the native title, Overview version, both visible ribbon lines, full tooltip/About details, ribbon acknowledgment (including mouse hit-testing, keyboard activation, and restoration after relaunch), narrow-window layout, and both About entry points. Omit the timestamp/commit arguments only when that metadata is absent. For PR builds, also supply `-PullRequestNumber <number>`. Run it on an interactive Windows desktop; the script launches and closes its own app instances and temporarily resizes them. Prefer GitHub Actions rather than interrupting a working desktop. The UI review workflow runs it against its stamped artifact, captures normal/narrow ribbon and About evidence, and temporarily enables high contrast on the disposable CI desktop, restoring the previous setting afterward.

`pwsh -File tests\BuildIdentity.Metadata.Tests.ps1` verifies current UTC stamping for every build kind and verbatim override preservation through MSBuild evaluation. Supply `-AppDirectory <published-directory> -BuildTimestamp <expected-time>` to also verify the actual compiled assembly metadata; CI and release publishing perform this check before uploading artifacts.

Without a saved theme preference, FingVibe starts with Standard Light or Standard Dark to match the Windows app mode. **Settings > Appearance** has four selectors; each remains independently adjustable after Glass applies its initial backdrop default:

| Setting | Options | Purpose |
| --- | --- | --- |
| Mode | Light, Dark | Overall brightness |
| Theme | Standard, Warm (Light) / True Black (OLED) (Dark), Colored, Vivid | Surface colors |
| Visual style | Standard, Glass, Clay, Neumorphic | Surface materials, rounding, bevels, and elevation |
| Window backdrop | Solid, Mica, Mica Alt, Acrylic | Material behind the page content |

Switching modes retains the theme family; Warm and True Black map to each other. Colored retains the former Colorful blue/violet and indigo palettes, including their stored names. Vivid has stronger blue surface saturation in both modes while preserving readable primary text and semantic status colors. Existing saved settings retain their theme and backdrop and start with Standard visual style.

The experimental styles use shared card and native control styling without rearranging individual pages. Standard retains the existing native appearance. Glass uses 63%-opaque palette-aware card and sidebar fills over the native window material, one-DIP white borders at 30% opacity, and low-elevation ThemeShadow on cards rather than heavy shadows on every control. Shared headers, container fills, and row stripes also allow the material through. With a supported native backdrop, soft violet, cyan and warm radial color gradients sit beneath the Glass surfaces so their translucency remains visible even with a neutral wallpaper. This noninteractive underlay disappears for Solid, unavailable materials, disabled transparency and high contrast. The navigation pane has a matching one-DIP specular outline; overlay navigation uses in-app Acrylic to blur underlying page text instead of displaying it through menu labels, with an opaque fallback when effects are disabled. Entering Glass selects Mica Alt once; the backdrop picker stays enabled, and subsequent choices (including Solid or Acrylic) are saved and respected. Loading saved settings, changing mode/theme, and leaving Glass do not reset the backdrop. Mica Alt uses a wallpaper-derived material; Desktop Acrylic provides behind-window blur. Clay uses generously rounded surfaces, broad three-pixel bevels, stronger light-to-shade gradients, and deeper raised shadows. Neumorphic blends surfaces into the page palette, with pronounced opposing three-pixel light/dark edges, raised cards, and inset field lighting. Native control templates, keyboard focus, selection, and hover states remain in place. Explicit page-specific control fills and borders take precedence over the shared control treatment. Solid shows the palette most faithfully; backdrop materials can soften its colors. True Black guarantees black base page/card colors in Standard style; decorative styles may add shading or translucency.

Clay uses 32-DIP card radii and 24-DIP field/search/control radii (short fields naturally clamp to a pill shape). Three-stop gradients run from a softly lit top-left edge through a rich body tone to a shaded bottom-right edge. Light surfaces retain their theme-family tint; dark surfaces gain a restrained blue ambient tone instead of flat charcoal. A three-stop inner border bevel supplies the soft white highlight, while native ThemeShadow at 40-DIP card / 12-DIP control elevation supplies diffused outer depth. Shadow color and opacity remain Windows-controlled rather than using a sharp custom black shadow. The open-ports filter panel shares the native-field treatment; page layout and semantic accents remain unchanged.

Appearance choices apply immediately and are saved to `%LOCALAPPDATA%\FingVibe\appearance.json` for the next launch; existing saved themes remain compatible and take precedence over Windows app mode. Ordinary Windows light/dark changes do not switch the theme while FingVibe is running. Unsupported backdrop materials fall back to a solid theme background without discarding your selection. Disabling Windows transparency effects uses opaque Glass surfaces and a solid window background, reports the fallback in Settings, and restores materials when effects are enabled again. Windows high contrast takes precedence, removes decorative shadows/gradients/materials, and uses system colors.

Settings places the four appearance selectors in one row when space permits, two paired rows at intermediate widths, or one column in narrower windows. Device-column choices use up to three columns in their existing order, with fewer columns as space decreases. IP address is always shown; **Reset columns** restores every column's visibility and default width. Column choices and widths last only until FingVibe closes. The page remains scrollable for small windows and larger text.

Public IP and ISP details are retrieved from `ipwho.is`. This optional display depends on internet access and sends the connection's public IP to that provider as part of the HTTPS request. LAN discovery and scanning continue to work when the lookup is unavailable.

Configured builds also show an ISP logo on the Network page, loaded asynchronously from Logo.dev using the original ISP name. Logo.dev receives that name and the caller's public IP, but no LAN addresses, device inventory, or scan results. Missing configuration, unavailable images, and failed or slow requests leave a generic network icon; the ISP text and scanning remain available. Name matching selects the provider's top result and can identify the wrong brand. UI-review mode never requests logos. See [ISP logo configuration](isp-logos.md) for build setup and provider limitations.

The Overview network card shows A, B, or C for /8, /16, or /24 sizes; other sizes show their CIDR prefix. Network details explain all prefixes from /0 through /32, including class-size multiples/divisions and point-to-point or single-host networks. Counts below one million are exact; larger counts use M with two significant digits. Ordinary subnet counts exclude network/broadcast addresses, with a reserved suffix for /17 through /30; /31 assumes point-to-point use and /32 identifies one host. These capacity figures do not change the scanner's 65,534-address safety limit. Scope checks cover the whole subnet, distinguish private and special-purpose ranges (including APIPA/link-local), and flag mixed scopes. "Standard-size private" means a private /8, /16, or /24 subnet, not that other private prefix lengths are invalid.

Results dim complete network-prefix octets using the scanned subnet's CIDR; partially masked octets remain emphasized because they also identify hosts. Latency bars share one scale across the displayed scan's responding devices and keep that scale when filtering or sorting. Outside a scan, select a row with the pointer or keyboard to highlight it; sorting preserves the selection. Hover over service icons for port numbers and service names.

In current device details, **Scan additional ports** checks a curated preset of
exactly 100 additional TCP ports, covering file sharing/storage, remote access,
mail, directory/authentication, databases/caches, messaging, web administration,
home automation/media, infrastructure, and printing. The automatic LAN scan
still checks only its original 10 TCP ports. The additional scan uses at most
16 simultaneous connections with 400 ms per-connection deadlines.

**Include UDP service checks** starts unchecked. Opting in sends only one
non-recursive DNS question to 53/UDP and one standard NTP client request to
123/UDP on the selected device, bound to the selected interface. Both checks
can run concurrently, with a 2-second deadline each, a 512-byte reply limit,
and no retries. Confirmed TCP results appear individually as each connection
finishes, without waiting for the remaining TCP probes or UDP; each protocol
has its own progress/status. The same button
becomes **Cancel additional scan** while running; leaving details also cancels.
Completed results remain available and are saved locally, including when the
other phase is canceled. Historical and imported-only addresses are not probed.

Only a matching valid reply confirms a responding UDP endpoint; valid DNS error
replies count as responses, not successful name resolution. UDP observations
are shown separately: **Responded**, **No response - inconclusive**, or **Error**
with details. Silence never establishes open/closed/filtered and does not add
an endpoint to the open-port filter or summary. Malformed replies and
operational failures are errors. Matching valid NTP kiss-of-death or
unsynchronized replies confirm that the service responded, but their details
explicitly warn that no usable time was supplied; no retry is sent.
These small read-only requests can still trigger device logs or security alerts.

Endpoint labels include protocol, for example **1883/TCP - MQTT** or
**123/UDP - NTP**, so TCP and UDP sharing a port number remain distinct.
Monochrome service-family icons are shared by the list and details with
descriptive tooltips and accessible names. Port names/icons describe common
or likely uses, not verified products; MQTT never implies RabbitMQ. UDP
observations are not used as TCP banner or device-classification evidence.
Existing saved entries without a protocol retain their TCP meaning.

`tests\AdditionalServices.Ui.Tests.ps1 -AppPath <published-exe>
-ScreenshotDirectory <output-directory>` exercises the default/opt-in controls,
independent progress, TCP-before-UDP completion, confirmed/inconclusive/error
states, cancellation, saved protocol identity, and service icons in all six
app themes. It uses synthetic loopback-only TCP/DNS/NTP responders and is wired
into GitHub Actions UI capture. Run it only on a disposable interactive desktop,
not a working user's desktop; it requires free loopback ports 1883/TCP, 53/UDP,
and 123/UDP and fails explicitly when they are unavailable. On disposable
GitHub Actions runners only, it temporarily stops Windows Time if running to
release 123/UDP and restores the service afterward. The application itself
needs no new administrator rights.

Devices shows the persistent inventory, including previously observed and imported-only devices. Unused addresses never become device records. The status filter distinguishes Online, Offline, Unknown, and Fing Only; retained observations without current scan evidence are Unknown, while last-seen information remains in details. The Devices title sits above the inventory card, matching Network's page-title styling, with the device count alongside it. Scan freshness and scan/save errors live in the shared shell header rather than being repeated inside the inventory card. **Search devices** expands with the window; the People, Rooms, and bordered **With open ports** controls have equal fixed widths and wrap below search when space is limited. Filtered counts show visible versus total devices. Subtle theme-aware zebra stripes follow the displayed row order, with native hover, selection, and focus indicators taking precedence; decorative stripes are disabled in Windows high contrast. A 1px theme-aware line below the column headers separates them from the rows, using system colors in high contrast. The compact Response column places its numeric latency above a thin bar without changing the scan-wide latency scale. The final visible column has no trailing divider suggesting an extra column; its resize handle remains available.

Starting a scan keeps the displayed list visible and scrollable but prevents opening device details by pointer or keyboard. Results are collected separately and replace the list only when the scan succeeds; cancellation or failure retains the displayed results and reports the outcome explicitly. Progress continues to count all checked addresses. Completed scans update inventory observations and same-network absence; this adds no event timeline or new discovery probes.

The expanded sidebar uses a 280px Windows Settings-style layout with colored navigation icons and a FingVibe header. The sidebar and main page share one background, including when a backdrop material is selected. Collapsing the pane keeps an icon rail; narrow windows use native overlay navigation, with Tools above Settings at the bottom. While an overlay is open, both backgrounds temporarily use the same solid theme color to keep the menu readable without a contrasting pane tint; closing it restores the selected material. Windows high contrast replaces decorative icon colors with system colors.

### Device identification

Devices show a native Segoe Fluent device icon beside their name. The **OS** and **Device type** columns can be sorted, resized, or hidden in Settings. Both detected and manually selected classifications are included in text filtering. Device details show the identification evidence and whether a value is user-selected. Unknown OS, device type, and vendor values use muted text in both the list and details.

Identification is best-effort and local. SSDP discovery uses the selected interface, and one shared multicast DNS-SD discovery window follows service announcements through SRV, TXT, and IPv4 address records to collect models without confusing proxy responses with the responding device. It listens for multicast replies as well as requested unicast replies. SSDP `SERVER` advertisements and bounded HTTP/SSH banner reads on already-open ports can identify OS-specific platform information. Merely running SSH, SMB, nginx, or Apache is not OS proof. The computer running the scanner is identified directly from its OS, and the selected interface's configured gateway is identified as a router.

Explicit device types/models outweigh service-only clues. When explicit evidence is absent, narrow product/manufacturer clues can suggest categories such as WD My Cloud/Synology/QNAP storage, Philips Lighting/Signify/Tuya smart devices, media devices, or game consoles. OS-specific discovered names, such as `Android-...`, are hints, not proof that the device is a phone. These inferred values are visibly marked **(likely)** in the list and details, with the supporting evidence shown in details. A generic TP-Link, Amazon, or Apple vendor, randomized MAC, or open SMB port alone does not determine an OS or device category. Conflicting or unsupported results remain **Unknown**; silent devices may still require manual correction. No fingerprinting cloud API is contacted; the existing vendor-registry downloads and optional public-network lookup are unchanged.

For otherwise unidentified SMB hosts, an observed ICMP response TTL of 127 or 128 together with open TCP 445 can suggest **Windows (likely)** and **Computer (likely)**. This is a combined heuristic, not definitive OS fingerprinting: it does not apply to known routers, NAS appliances, smart devices, or contradictory OS evidence. TTL alone, SMB alone, and Linux/macOS-style TTL values do not produce an OS guess.

Device details keep the OS, type, and icon visible above the network information and port-scan action. Expand **Identification evidence and corrections** below the network details to inspect the evidence, choose an operating system, device type, and/or a built-in icon, then select **Save identification**. **Automatic** restores detection for an individual field when no mapped Fing metadata is available; otherwise that option explicitly says **Use imported Fing OS/type**. **Use automatic detection** (or **Clear saved corrections** for imported devices) clears all three saved choices, restoring the imported/automatic fallback without deleting imported metadata. The icon follows the effective device type unless an explicit icon is selected. Available types include Computer, Phone, Tablet, Router/access point, Printer, TV/media device, NAS/storage, Game console, IoT/smart device, and Unknown. Categories without reliable discovery evidence can be assigned manually; OS also offers Other.

Corrections are stored separately from automatic evidence within `%LOCALAPPDATA%\FingVibe\device-inventory.json`, keyed by MAC address, and apply after rescans, IP changes, and restarts. Existing `device-classifications.json` data is migrated without deleting or rewriting the legacy file. Saving requires a six-byte MAC address, including an imported MAC. Private/randomized MACs may change and therefore lose their association with saved corrections. Load/save errors are shown in details; a failed load disables edits rather than overwriting existing corrections. Completed scan snapshots preserve automatic evidence and inferred-value markers. Older snapshots remain readable, but are not re-enriched when opening a new build: run **Scan LAN** again to collect current detection evidence.

For private-prefix virtual devices, corrections instead belong to the persistent virtual identity and follow its inferred MAC changes; underlying MAC-specific corrections are preserved separately.

### People and rooms

Each person and room can select a predefined monochrome **Icon** in Add/Edit.
People offers person silhouettes; Rooms offers room, home, bedroom (sleep),
kitchen (cup), living room (TV), office (briefcase), garage (car), and garden
(leaf) symbols. The selected icon appears at 16 DIP beside the name in the
People/Rooms list and at 48 DIP above the short name in its detail header.
Icons follow theme text colors, including high contrast, and do not replace
names or accessible labels. They are decorative: assignments, device tables,
assignment pickers, search, sorting, and response counts are unchanged.
Choices are saved with each entry as stable IDs. Existing entries use a generic
person or room icon; an unavailable saved ID displays the generic icon with a
diagnostic and remains preserved unless a different choice is selected.

Short-name limits count visible characters, so a multi-code-point emoji such as `0️⃣` counts as one. Room short-name inputs, the room list and details, and Devices room assignments use Segoe UI Emoji for consistent color-emoji rendering; saving preserves the original Unicode sequence.

The **People** and **Rooms** pages manage manually named people and locations. Each entry has a full name, a unique 1–3-character short name within its category, and optional notes. New entries suggest initials from the first two words as you type (`Igor` → `I`, `Igor Iric` → `II`, `Living Room` → `LR`); editing the short name manually stops automatic updates. Device details can assign one person and one room independently; either can remain unassigned. The Devices table shows plain short-name text in optional **Person** and **Room** columns, with muted dashes for unassigned values, while filters and search match both short and full names. Hover over a short name or keyboard-focus it to access its full-name tooltip and accessible label.

People, rooms, and their assignments are saved separately from scan snapshots within `%LOCALAPPDATA%\FingVibe\device-inventory.json`. Existing `people-rooms.json` data is migrated without deleting or rewriting the legacy file. Assignments require a six-byte MAC address, including an imported MAC, and never use an IP address alone. Private or randomized MAC addresses may change, so their assignments are only retained when the same MAC is observed again. Deleting a person or room clears only that category's assignments; it does not delete devices or scan history. Last-scan response counts report devices that answered ICMP during the displayed scan, not human presence; no response does not prove a device is powered off. Load and save errors are displayed, and a failed load disables changes to protect the saved file.

Assignments edited on a private-prefix virtual device belong to its persistent identity and follow inferred MAC changes, rather than being copied to its member MACs.

## Inventory and Fing import

**Tools > Import from Fing** accepts one local `.xlsx` workbook through Browse or
drag-and-drop. Export help is collapsed initially. Fing's current
[Network View documentation](https://help.fing.com/hc/en-us/articles/26652272065820-Network-View)
describes the Web App's network Setup > Export > Send workflow, delivering an
Excel spreadsheet by email. Desktop/mobile menus and availability vary with
version and subscription; CSV, PDF, text exports, and arbitrary spreadsheets
are not supported. The supported workbook has one Devices sheet and a MAC
header, with the optional Name, Hostname, Type, Brand, Family, Model, OS,
OS Version, Owner, Location, and IP columns. Limits are 10 MB compressed,
64 MB uncompressed, and 20,000 device rows. Formulas are not executed or trusted.

Analysis is read-only and groups People, Rooms, private/randomized MACs,
skipped records/fields, and a combined **Device type / OS classification** warning
group. People/Rooms groups have
standard management buttons at the top-right of their cards and confirm when
all referenced entries match or none are referenced.
Expanded details identify affected devices by available name or formatted MAC,
showing the first 10 per detail followed by an omitted-count notice when needed.
Diagnostic references retain worksheet rows; skipped records without a retained
device identity show their row instead. Counts remain complete and text wraps.
The filename gains an Excel-inspired green chip and outline in every light/dark
appearance after successful analysis and returns to
neutral when analysis is cleared or invalidated; this does not approve every field.
Windows high-contrast mode retains system colors.
Excluded Fing data and historical-IP semantics appear as an informational note,
not a warning. The separate **3 Changes and conflicts** container groups the preview by device/MAC, with compact additions,
explicit before/after conflicts, and reasons for skipped fields; absent fields
are omitted and unchanged devices are collapsed. Existing names, imported metadata, manual classifications,
and assignments are kept unless their individual conflict choice is changed
to Replace. Empty fields never erase saved data. Detailed Fing types and OS
strings remain available in details even without a reliable category mapping;
uncertain mappings produce warnings. Manual corrections take precedence over
imported classifications, which take precedence over automatic detection.
Name precedence is user name > imported name > local hostname > imported
hostname > last-known local/imported IP; IP fallback names are subdued.

Device-card headers have a subtle theme-aware background band and put bold names and MACs alongside normal-weight change counts;
nonzero conflicts have a critical-color indicator. Compact rows group identity,
hardware, operating-system/address, and assignment fields. Non-interactive label
chips distinguish field names from values without creating false button actions.
Labels, values, and conflict controls are center-aligned within each wrapping field unit.
Device cards use 6-unit outer vertical padding and 2-unit padding on each side
of the header/details join, with 4-unit spacing between detail rows.
Names use Segoe UI Emoji for supported color emoji sequences, preserving their text.
**Fing IP** is the historical exported address, used as display/search context and
a final name fallback only; it never identifies a device or authorizes a probe.
Private/locally administered MACs appear as informational notices, not warnings.
Affected cards recommend leaving unrecognized devices unchecked in Select devices
mode; they remain importable, and Import all still includes every eligible device.
New devices containing only MAC/historical Fing IP receive a **Limited information**
recommendation to skip them unless recognized. Useful metadata, assignment references,
or existing saved information prevent that recommendation. It does not exclude
devices automatically or disable importing them.
Cards sort by conflicts, then additions, then skipped fields, all descending.
Exact ties sort by MAC ascending; changing choices/importing refreshes the ordering.

Owner matches a managed person's full name and Location a managed room's full
name, after trimming and case-insensitive comparison. Exactly one match is
required. Missing/ambiguous entries skip only that assignment field, not the
device; use the management buttons, return to Tools, and Analyze again.
Import does not create people/rooms, infer owners, import Group, or migrate
Fing events/timestamps. Invalid MACs and all duplicate-MAC rows are skipped
with explicit warnings. Devices sharing an IP remain distinct by MAC.

Online means a response in this session's latest completed local scan;
Offline means locally observed previously but absent from a subsequent
successful scan of that same Windows network profile and subnet. Other-network,
cancelled, and failed scans do not infer absence. When network identity is
unavailable or changes during a scan, a warning is shown and absence is not
inferred. Fing Only means the inventory has no local observation of the imported
MAC, regardless of Fing's State field. First local discovery removes that state.
After restart, retained observations are Unknown, not Online or freshly Offline.
Observations outside the latest successful scan's network/subnet are also
Unknown; their last-seen information is retained. A failed or cancelled refresh
keeps the previous successful scan's evidence unchanged. People/Rooms
live-response summaries do not count imported or restored records. Overview and
Network Online counts count current device identities, not historical members
or duplicate IPs for one MAC. Historical/Fing-only addresses cannot
start an additional port probe until a current local response exists.

### Private-prefix virtual devices

Sparse, globally administered MACs with vendor exactly **Private** are eligible
when they have no meaningful saved/imported name, hostname, device type, OS,
family or model. An IP-only name is not identification. **Private** means an
undisclosed IEEE registrant, not a randomized MAC or a known manufacturer.
Locally administered/randomized MACs and meaningful MAC-specific metadata are
not automatically grouped.

On each successful scan of an identified Windows network profile and subnet,
eligible MACs occupy persistent virtual devices named **Private D0-C9-07**,
**Private D0-C9-07 -2**, etc. Each virtual device has at most one responding MAC,
but that MAC can have several responding IPs. Known returning MACs are reserved
first. New MACs take the lowest-numbered available device; only additional
simultaneous responders beyond the existing capacity create another number.
If previously associated MACs return together, the last-active member has
preference, with MAC order as the deterministic tie-breaker; extra members use
available/new slots. A returning MAC prefers its most recently used association.
Numbers are retained when devices become Offline; they are not renumbered.
Unscoped restored observations and unrelated network/subnet contexts are not
used to infer an association.
Previously unassociated eligible history in that same known context joins the
lowest-numbered virtual device on a successful scan, with an inference notice
and its original first/last-seen times. If only historical members exist, number
1 is created Offline after that scan establishes their absence.

Select a virtual-device row to edit its name, identification or Person/Room
assignments; these belong to the virtual device and follow its MAC changes.
Expand **MAC and address history** for full selectable MAC/IP pairs, first/last
seen times, network/subnet, endpoint evidence and preserved MAC-specific data.
Each numbered device keeps its own history. Association by prefix and available
number is explicitly **inferred**, not proof of one physical device.
Underlying full-MAC records and existing metadata/assignments remain intact;
Fing imports still match full MACs, never virtual device names or prefixes.
If meaningful MAC-specific identification arrives later, that record is shown
normally while the virtual device's prior history is retained.

When one MAC responds at multiple addresses, details offer **Current address
to inspect / probe**. Ports and additional probes in details belong to that
selected responding address; the list's port filter counts the device if any
current address has an endpoint. IP changes do not create another identity.
Search can find virtual devices through historical MACs and addresses.

On Devices, the status filter sits directly beside text search in the filter bar;
its semibold text and stronger theme-aware accent border distinguish it from the
other filters, which retain responsive wrapping at narrower window widths.

The version-2 `device-inventory.json` contains inventory, local observations,
names, classification corrections, People/Rooms and persistent virtual devices
in one atomic commit. Version-1 inventories remain readable and migrate on save.
Older inventory-aware builds reject version 2 rather than silently dropping its
virtual devices or multiple-address observations. It
becomes authoritative after the first successful save; legacy `device-names.json`,
`device-classifications.json`, and `people-rooms.json` are retained untouched.
Available legacy snapshot observations are restored as historical with unknown
network identity; unavailable older history is not invented. `latest-scan.json`
and appearance settings keep their existing formats. Older app builds do not
read the new inventory, and their legacy-file edits are not synchronized back
after migration. Load failures disable changes rather than overwriting data.
Use **Import device** to save one device or **Import all** for all eligible changes.
**Select devices** switches to checkboxes and **Import selected (N)**, with
Select all / Deselect all and Cancel selection. Selection starts empty; changing
modes never saves or resets overwrite decisions. Every operation saves only its
requested devices together, completely or not at all. Import all does not approve
overwrites: all operations respect the preview's keep/replace choices.
After success, the remaining preview refreshes and retains valid pending choices.
**Imported this session** records saved progress; devices with preserved conflicts
or skipped assignments retain their remaining items. Imported does not mean every
Fing field was accepted. Save failures do not commit a partial batch.

Changing the file, conflict choices, or relevant saved data invalidates or
refreshes the preview. Import checks that the file bytes are unchanged and that
the saved inventory revision still matches. Another app instance's committed
changes cause an explicit stale-data error rather than an overwrite.

`tests\FingImport.Ui.Tests.ps1 -AppPath "<absolute app path>"` exercises a fully
synthetic preview, management return/re-analysis, completion, inventory counts,
and status filtering on an interactive Windows desktop. UI-review mode keeps
inventory edits in memory and never imports the user's private export.

## Test

```powershell
dotnet test tests\FingVibe.Core.Tests\FingVibe.Core.Tests.csproj
```

On an interactive Windows desktop at least 1024 logical pixels wide, run the native sidebar regression checks against a built application:

```powershell
powershell.exe -NoProfile -File tests\SidebarNavigation.Tests.ps1 `
    -AppPath "<absolute path to FingVibe.App.exe>" `
    -ScreenshotDirectory "$env:TEMP\FingVibe-sidebar-review"
```

These checks use Windows UI Automation without WinAppDriver or Developer Mode. They launch a separate app in deterministic UI-review mode, verify page routing and expanded/compact/overlay navigation, compare solid sidebar/page background pixels in all eight themes, and save full-window captures for each backdrop. They also verify all 128 independent mode/theme/style/backdrop combinations, capture each visual style in both modes, check responsive Settings and mode/theme mapping, column visibility/reset, retained devices during refresh/cancellation, filtered counts, and non-overlapping device filters at wide and narrow widths, restoring the original scan snapshot afterward. Settings checks acknowledge the non-release ribbon to compare the normal release viewport; build-identity checks independently cover its reserved space and acknowledgment. The expanded test adapts to the monitor width (up to 1280 logical pixels), with a maximum window height of 720 logical pixels; pass `-ExpandedWindowWidth 1024` to reproduce the hosted runner's 1024x720 viewport on a larger desktop. UI-review mode previews appearance changes without saving them. Verify Windows high contrast separately using the system accessibility settings.

`tests\DevicesList.Ui.Tests.ps1 -AppPath "<absolute path to FingVibe.App.exe>" -ScreenshotDirectory "<capture directory>"` checks the expanding search, equal 180px filter components, compact response layout, zebra stripes, sorting/filtering, container recycling, and native interaction indicators on an interactive desktop at least 1280 logical pixels wide. It uses an isolated 80-device snapshot through `FINGVIBE_UI_REVIEW_SNAPSHOT`, which is honored only in UI-review mode, and deletes that fixture afterward without modifying the user's saved scan or appearance.

## Download builds

Local and pull request build/publish outputs retain only English (`en`) managed satellite resources through the application's `SatelliteResourceLanguages` setting. Neutral resources, including dependencies' default English strings, remain included. Official releases retain all available languages: the release workflow overrides the setting with an empty global MSBuild property (`/property:SatelliteResourceLanguages=`), disabling this filter. Both workflows use the Release configuration, so the configuration name alone does not determine language filtering. This does not force the runtime UI culture to English or filter Windows App SDK native/PRI resources in the self-contained deployment. When checking the result locally, start with clean build and publish output directories: previously copied language folders are not removed by changing this setting.

Pull requests affecting application code or validation infrastructure upload a `fingvibe-win-x64-pr-*` artifact from the **🔨 Pull request build** Actions run, plus a `fingvibe-setup-win-x64-pr-*` installer artifact. Each successful same-repository build posts a new runnable-app artifact-link comment, preserving earlier comments and links (artifacts expire after 14 days). Artifact names include the run attempt, so reruns do not replace earlier downloads. Documentation-only and ordinary test-only changes do not publish an app. Every push to `main` publishes a GitHub Release tagged `v1.0.<run number>` with a self-contained Windows x64 ZIP and `FingVibe-<version>-win-x64-Setup.exe`, both from the same published binaries.

The unsigned Inno Setup installer supports Windows 11 x64 and installs only for
the current user at `%LOCALAPPDATA%\Programs\FingVibe`, without requesting
administrator rights. It adds a Start menu shortcut and a Windows **Installed
apps** entry; a desktop shortcut is optional. Windows may show an unknown
publisher or SmartScreen warning. No code signing or automatic updater is
included; download only builds you trust.

For manual updates, close FingVibe and run the newer installer. Setup refuses to
install or uninstall while FingVibe is running and rejects downgrades. Existing
files from the ZIP convenience script can be adopted in the same location.
Upgrades remove obsolete files recorded in the previous installer's ownership
manifest, not arbitrary directory contents. Unrecognized files from earlier
ZIP/script installations are retained, even if they appear obsolete.
Do not use the ZIP convenience script to update an installer-managed copy;
use Setup so version registration and file ownership remain consistent.

Uninstall through Windows **Installed apps**. Saved settings, inventory, and
other user data in `%LOCALAPPDATA%\FingVibe` remain, as do unknown files in the
installation directory. ZIP and installed copies share this per-user data;
installation does not create an isolated profile.

Contributor packaging uses Inno Setup 6 (`ISCC.exe`, preinstalled on the Windows
GitHub runners). After publishing the app, run:

```powershell
.\tools\New-Installer.ps1 -AppDirectory artifacts\fingvibe-win-x64 `
    -Version 1.0.123 -OutputDirectory artifacts\installer
```

`tests\Installer.Script.Tests.ps1` checks packaging helpers without installing or
launching anything. `tests\Installer.Lifecycle.Tests.ps1` refuses to run outside a
disposable GitHub-hosted runner. PR and release builds compile the actual
installer and verify payload hashes, fresh installation, window launch,
running-app blocking, ZIP/script adoption, upgrade cleanup, downgrade rejection,
shortcuts, uninstall, and saved-data/unknown-file preservation. Test-only future
version installers reuse the payload to exercise upgrades; they are not
published. Installer logs are retained as Actions artifacts, including on failure.
Any installer failure blocks release publication.

Keep the extracted app files together: `Assets\Scanner.ico` supplies the running window's title-bar and taskbar icon. The executable also embeds the same icon for File Explorer.

## Pull request review gates

Pull requests expose two review checks:

- `security-review` scans the repository for exposed secrets and fails on critical dependency vulnerabilities.
- `ui-ux-review` launches the tested WinUI app, exercises the primary **Scan LAN** action, verifies critical accessible controls, and embeds fresh screenshots of Devices and the affected views/states on the pull request.

The **🔨 Pull request build** workflow runs core/script tests and one Windows publish concurrently after change planning. Once both pass, installer packaging/lifecycle validation and native UI validation run on separate Windows runners in parallel. Both download the same published payload; neither rebuilds the app. Desktop UI suites remain sequential on their runner to avoid competing for focus and input. UI-review mode is enabled only at runtime, so the downloaded app remains the normal executable.

Publishing uploads a short-lived `fingvibe-validation-payload-pr-*` transfer artifact (one-day retention), explicitly not a tested download. Publishing may finish even if concurrent tests fail. The installer job publishes the existing runnable-app and tested-installer downloads only after core tests and installer lifecycle checks pass; the build-link comment follows that job. Screenshot publication also waits for installer and UI validation to succeed. The required `ui-ux-review` gate aggregates tests, publishing, installer/download validation, native UI checks, and screenshot publication; failed, cancelled, or unexpectedly skipped required stages cannot pass. Separate jobs add runner startup and artifact-transfer overhead, so time savings depend on the run.

Superseded runs on the same PR are cancelled. Documentation-only changes skip tests/build/installer/capture, while ordinary test-only changes run the regression tests without publishing or launching the app. Changes to the interactive screenshot regression tests run the native UI path as well. Workflows still start for every PR, and the `ui-ux-review` gate reports intentional skips or prerequisite failures rather than leaving a required check pending. Security scanning remains independent and runs on every PR.

Manual runs of **🔨 Pull request build** force tests, build, and UI validation, including optional `additional_scenarios`. Read-only jobs execute tests, build, and UI automation without write permissions or persisted Git credentials. Separate publishing jobs receive only the content/comment writes they need. Fork and untrusted-contributor restrictions remain in place; Dependabot runs do not post comments.

The UI check runs on GitHub's `windows-2025` image and uses its preinstalled WinAppDriver to launch and automate the native application in dark theme. It also exercises overview-card navigation (including keyboard activation), clearing stale filters and enabling/disabling the visible open-port filter. It runs automatically only for same-repository pull requests from trusted collaborators; fork pull requests are not executed. The workflow sets `FINGVIBE_UI_REVIEW=1`, which confines the smoke-test scan to the single loopback host `127.0.0.1/32`, allowing real discovery and enrichment to finish before capturing the hosted-runner review.

Before exercising the UI, the capture script restores and centers the application window inside the monitor's working area, shrinking it only when the desktop cannot fit its initial size. It captures the complete native window (including its title bar and edges) directly from the screen using DPI-aware physical-pixel bounds rather than WinAppDriver's screenshot endpoint. Off-screen, minimized, undersized (below 640 x 480), unfocused, moving/resizing, or blank captures fail the check instead of publishing a clipped image. The workflow logs the original bounds, monitor working area, DPI, and final capture dimensions for diagnosis.

The Windows screenshot regression tests deliberately place a patterned window off-screen and then oversize it. They verify that capture rejects clipping, fits the window on-screen, and preserves all four corner markers in a PNG whose dimensions match the complete window. Run them on an interactive Windows desktop with `pwsh -File tests\UiReviewScreenshot.Tests.ps1`.

When UI review runs, the capture plan always includes **Devices** after its scan/filter smoke test. The PR's merge-base diff selects additional views: page-local XAML changes select that page; device-details and network-identity code select their respective views; results/filter/column changes include the empty-results state and Settings. Tools/speed-test changes select **Tools** and **Speed test**, so a change adding that feature produces exactly those two screenshots plus Devices. Navigation-menu changes are demonstrated in Devices instead of capturing every existing page. Shared window layout and theme/appearance changes still select all scenarios; other application/core and review-pipeline changes use the Devices baseline unless a page-specific rule applies. New views must have explicit capture/navigation rules rather than silently falling back to unrelated screenshots.

Navigation verification is independent of screenshot selection: every supported scenario is exercised, even when only Devices is captured. Existing scan/filter, overview navigation, People/Rooms suggestions, and assignment smoke tests remain enabled. Each capture verifies the selected navigation item and visible page-specific controls; required navigation or capture failures stop the review instead of silently showing the wrong page.

The workflow logs selection reasons and uploads the capture plan, completed manifest, and all PNGs together. Available partial captures, WinAppDriver output, startup/crash diagnostics, and the smoke-test transcript are retained on failure; a completed manifest is written only after all required checks pass. Its existing PR screenshot comment is updated with labeled images, without repeating the detailed file-by-file selection reasons. Security/UI failure comments are still updated and cleared when resolved; only build-artifact comments are append-only. Manual runs can request extra scenarios through the comma-separated `additional_scenarios` input: `Overview`, `Network`, `DeviceDetails`, `People`, `PersonDetails`, `Rooms`, `RoomDetails`, `Tools`, `SpeedTest`, `About`, `Settings`, and `DevicesEmpty`. People and Rooms captures use in-memory review records instead of loading or changing saved user data. New pages or required states must be added to the scenario catalog, selection, navigation, and regression tests. Run the scenario regression tests with `pwsh -File tests\UiReviewScenarios.Tests.ps1`, and validation-planning/comment/gate regression tests with `pwsh -File tests\PrValidation.Tests.ps1`.

The workflow publishes screenshots to the `gh-pages` branch so the bot can embed the PNGs directly in its review comment. After the workflow creates that branch for the first time, open **Settings > Pages**, choose **Deploy from a branch**, select `gh-pages` and `/ (root)`, then save. Published image URLs use `https://<owner>.github.io/<repository>/ui-review/pr-<number>/run-<run-id>/<filename>.png`, keeping captures from different runs separate.

After both workflows have run at least once, configure them as required checks:

1. Open **Settings > Rules > Rulesets** and create or edit the branch ruleset for `main`.
2. Enable **Require status checks to pass**.
3. Add `security-review` and `ui-ux-review`.
4. Enable **Require branches to be up to date before merging**.

Do not merge when either check fails. A detected secret or critical vulnerability fails `security-review`; an app launch, rendering, screenshot, accessibility, or primary-interaction failure fails `ui-ux-review`.