using System.Net;
using System.Runtime.InteropServices;
using System.Text.Json;
using FingVibe.Core.Formatting;
using FingVibe.Core.Models;
using FingVibe.Core.Networking;
using FingVibe.Core.Storage;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Windows.Networking.Connectivity;
using Windows.UI;
using Windows.UI.ViewManagement;

namespace FingVibe.App;

public sealed partial class NetworkTroubleshootingPage : UserControl
{
    private readonly NetworkDiscoveryService _discovery = new();
    private readonly NetworkDiagnosticService _service = new(new NetworkDiagnosticProbes());
    private readonly RouterWanSettingsStore _store = new(Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FingVibe", "router-wan.json"));
    private readonly AccessibilitySettings _accessibility = new();
    private readonly UISettings _uiSettings = new();
    private readonly Dictionary<DiagnosticCheckpoint, DiagnosticObservation> _observations = [];
    private readonly DiagnosticContextState _contextState = new();
    private CancellationTokenSource? _cancellation;
    private Task? _runTask;
    private LanNetwork? _network;
    private LanNetwork? _shellNetwork;
    private Guid? _networkId;
    private bool _updatingInput;
    private bool _settingsLoaded;
    private bool _refreshing;
    private bool _open;
    private bool _processingNetworkChange;
    private bool _networkChangePending;
    private NetworkDiagnosticReport? _report;
    private static bool IsUiReview => Environment.GetEnvironmentVariable("FINGVIBE_UI_REVIEW") == "1";

    public NetworkTroubleshootingPage()
    {
        InitializeComponent();
        _diagramTimer.Tick += DiagramTimer_Tick;
        Loaded += (_, _) =>
        {
            _uiSettings.ColorValuesChanged += ColorsChanged;
            if (OperatingSystem.IsWindowsVersionAtLeast(10, 0, 19041))
                _uiSettings.AnimationsEnabledChanged += AnimationSettingsChanged;
            NetworkInformation.NetworkStatusChanged += NetworkChanged;
        };
        Unloaded += (_, _) =>
        {
            _uiSettings.ColorValuesChanged -= ColorsChanged;
            if (OperatingSystem.IsWindowsVersionAtLeast(10, 0, 19041))
                _uiSettings.AnimationsEnabledChanged -= AnimationSettingsChanged;
            NetworkInformation.NetworkStatusChanged -= NetworkChanged;
            _contextState.Invalidate();
            StopDiagramAnimation();
            _cancellation?.Cancel();
        };
        ActualThemeChanged += (_, _) => Render();
    }

    public event EventHandler? BackRequested;
    internal NetworkActivityCoordinator? ActivityCoordinator { get; set; }
    public bool HasActiveTest => _runTask is { IsCompleted: false };

    public void SetNetworkContext(LanNetwork? network) => _shellNetwork = network;

    public async Task OpenAsync()
    {
        _open = true;
        if (_runTask is { } run) await run;
        if (!_open) return;
        RefreshNetworks(_shellNetwork);
        RunButton.Focus(FocusState.Programmatic);
    }

    public async Task StopForNavigationAsync()
    {
        _open = false;
        _contextState.Invalidate();
        StopDiagramAnimation();
        _cancellation?.Cancel();
        if (_runTask is { } run) await run;
    }

    public Task StopForWindowCloseAsync() => StopForNavigationAsync();

    private void ColorsChanged(UISettings sender, object args) => DispatcherQueue.TryEnqueue(Render);

    private void NetworkChanged(object sender) => DispatcherQueue.TryEnqueue(async () =>
    {
        if (!_open || !IsLoaded || IsUiReview) return;
        _networkChangePending = true;
        if (_processingNetworkChange) return;
        _processingNetworkChange = true;
        try
        {
            do
            {
                _networkChangePending = false;
                await CheckNetworkContextAsync();
            } while (_open && IsLoaded && _networkChangePending);
        }
        finally { _processingNetworkChange = false; }
    });

    private async Task CheckNetworkContextAsync()
    {
        var revision = _contextState.Revision;
        try
        {
            var current = ReadCurrentNetworkContext();
            if (DiagnosticContextState.Matches(_network, _networkId, current.Network, current.Profile)) return;
            StopDiagramAnimation();
            _cancellation?.Cancel();
            if (_runTask is { IsCompleted: false } run)
            {
                await run;
                if (!_open || !IsLoaded || revision != _contextState.Revision) return;
                current = ReadCurrentNetworkContext();
                if (DiagnosticContextState.Matches(_network, _networkId, current.Network, current.Profile)) return;
            }
            if (!_open || !IsLoaded || revision != _contextState.Revision) return;
            RefreshNetworks(current.Network);
            ProgressText.Text = "The selected network context changed. Context refreshed; run checks again.";
        }
        catch (Exception exception) when (exception is COMException or InvalidOperationException or InvalidCastException
            or System.Net.NetworkInformation.NetworkInformationException or ArgumentException)
        {
            if (!_open || !IsLoaded || revision != _contextState.Revision) return;
            StopDiagramAnimation();
            _cancellation?.Cancel();
            _settingsLoaded = false;
            SettingsStatus.Text = $"Network change verification failed: {exception.Message} Existing results are retained but may be stale; refresh adapters before running again. WAN persistence is disabled until refreshed.";
        }
    }

    private (LanNetwork? Network, Guid? Profile) ReadCurrentNetworkContext()
    {
        var current = DiagnosticContextState.Select(_discovery.GetAvailableNetworks(), _network);
        return (current, current is null ? null : WindowsNetworkProfileIdentity.GetNetworkId(current));
    }

    private void RefreshNetworks(LanNetwork? preferred)
    {
        try
        {
            _refreshing = true;
            var networks = IsUiReview
                ? _shellNetwork is { } fixture ? new[] { fixture } : Array.Empty<LanNetwork>()
                : _discovery.GetAvailableNetworks();
            AdapterPicker.ItemsSource = networks;
            AdapterPicker.DisplayMemberPath = nameof(LanNetwork.DisplayLabel);
            AdapterPicker.SelectedItem = DiagnosticContextState.Select(networks, preferred);
            ApplyNetwork(AdapterPicker.SelectedItem as LanNetwork);
        }
        catch (Exception exception) when (exception is System.Net.NetworkInformation.NetworkInformationException or InvalidOperationException)
        {
            AdapterPicker.ItemsSource = null;
            ApplyNetwork(null);
            ProgressText.Text = $"Adapter discovery failed: {exception.Message}";
        }
        finally { _refreshing = false; }
    }

    private void ApplyNetwork(LanNetwork? network)
    {
        _network = network;
        _networkId = null;
        _settingsLoaded = false;
        _updatingInput = true;
        WanInput.Text = string.Empty;
        try
        {
            if (IsUiReview)
                SettingsStatus.Text = "UI-review mode: WAN settings are not loaded or saved, and network probes are disabled.";
            else if (network is null)
                SettingsStatus.Text = "No adapter selected. WAN persistence is unavailable.";
            else
            {
                _networkId = WindowsNetworkProfileIdentity.GetNetworkId(network);
                WanInput.Text = _store.Load(_networkId.Value);
                _settingsLoaded = true;
                SettingsStatus.Text = "Valid WAN edits are saved for this Windows network profile; clearing removes only this network's value.";
            }
        }
        catch (Exception exception) when (exception is COMException or InvalidOperationException or InvalidCastException
            or IOException or UnauthorizedAccessException or JsonException or ArgumentException)
        {
            SettingsStatus.Text = $"WAN settings unavailable: {exception.Message} Edits will not overwrite saved settings.";
        }
        finally
        {
            _contextState.RecordWanText(WanInput.Text);
            _updatingInput = false;
        }
        ContextText.Text = network is null ? "No active LAN adapter." : $"Selected: {network.DisplayLabel} - Gateway: {network.GatewayAddress?.ToString() ?? "unavailable"}";
        WanHelp.Text = $"Open your router administration page in a browser, usually http://{network?.GatewayAddress?.ToString() ?? "<gateway shown above>"}. Sign in there and find Internet, WAN, or Status. Copy the WAN/Internet IPv4 address, not the router LAN address. Never enter router credentials into FingVibe.";
        ResetResults();
    }

    private void AdapterPicker_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var selected = AdapterPicker.SelectedItem as LanNetwork;
        if (!_refreshing && !HasActiveTest && selected != _network) ApplyNetwork(selected);
    }

    private void RefreshButton_Click(object sender, RoutedEventArgs e) => RefreshNetworks(_network);

    private void WanInput_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (!_contextState.AcceptWanEdit(WanInput.Text, _updatingInput)) return;
        try
        {
            RouterWanAddress.Parse(WanInput.Text);
            if (_settingsLoaded && _networkId is { } id && !IsUiReview)
            {
                _store.Save(id, WanInput.Text);
                SettingsStatus.Text = string.IsNullOrWhiteSpace(WanInput.Text)
                    ? "Cleared this network's remembered WAN address."
                    : "WAN address saved for this Windows network profile.";
            }
            else
                SettingsStatus.Text = "WAN address is valid (or blank), but persistence is unavailable for this context. No saved value was changed.";
        }
        catch (Exception exception) when (exception is ArgumentException or IOException or UnauthorizedAccessException or JsonException)
        {
            SettingsStatus.Text = $"WAN input/settings error: {exception.Message} The previously saved valid value was not replaced.";
        }
        ResetResults();
    }

    private void ResetResults()
    {
        _contextState.Invalidate();
        StopDiagramAnimation();
        _report = null;
        _observations.Clear();
        IPAddress? wan = null;
        try { wan = RouterWanAddress.Parse(WanInput.Text); }
        catch (ArgumentException) { /* The visible input error is set by the edit/run handler. */ }
        foreach (var observation in NetworkDiagnosticService.CreateCheckpoints(_network, wan))
            _observations.Add(observation.Checkpoint, observation);
        TracePanel.Children.Clear();
        TraceStatus.Text = "Not run. Up to 16 hops, one ICMP probe per hop, 1.5-second timeout.";
        ProgressText.Text = "Ready. No checks have run.";
        Render();
    }

    private void RunButton_Click(object sender, RoutedEventArgs e)
    {
        if (HasActiveTest) return;
        if (IsUiReview)
        {
            ProgressText.Text = "UI-review mode does not send diagnostic probes.";
            return;
        }
        IPAddress? wan;
        try { wan = RouterWanAddress.Parse(WanInput.Text); }
        catch (ArgumentException exception)
        {
            SettingsStatus.Text = $"Invalid WAN address: {exception.Message}";
            WanInput.Focus(FocusState.Programmatic);
            return;
        }
        try
        {
            var current = _discovery.GetAvailableNetworks().FirstOrDefault(item =>
                item.InterfaceId == _network?.InterfaceId && item.LocalAddress.Equals(_network?.LocalAddress));
            var currentId = current is null ? (Guid?)null : WindowsNetworkProfileIdentity.GetNetworkId(current);
            if (!DiagnosticContextState.Matches(_network, _networkId, current, currentId))
            {
                RefreshNetworks(current);
                ProgressText.Text = "Network context changed. Review the adapter and this network's WAN input, then run again.";
                return;
            }
        }
        catch (Exception exception) when (exception is COMException or InvalidOperationException or InvalidCastException
            or System.Net.NetworkInformation.NetworkInformationException or ArgumentException)
        {
            // Probes may still run without persistence, but never reuse an address from an unverified profile.
            if (!string.IsNullOrWhiteSpace(WanInput.Text) && _networkId is not null)
            {
                SettingsStatus.Text = $"Network identity verification failed: {exception.Message} Refresh adapters before using the saved WAN address.";
                return;
            }
            SettingsStatus.Text = $"Network identity verification unavailable: {exception.Message} WAN persistence is disabled.";
            _settingsLoaded = false;
        }
        if (ActivityCoordinator is null || !ActivityCoordinator.TryAcquire(NetworkActivityKind.NetworkTroubleshooting, out var lease))
        {
            ProgressText.Text = "Network activity coordination is unavailable, or a LAN scan/speed test/diagnostic run is active or stopping. Wait and retry.";
            return;
        }
        ResetResults();
        _cancellation = new CancellationTokenSource();
        BeginDiagramAnimation();
        SetRunning(true);
        _runTask = RunAsync(wan, lease, _cancellation);
    }

    private async Task RunAsync(IPAddress? wan, IDisposable? lease, CancellationTokenSource cancellation)
    {
        using (lease)
        {
            var started = DateTimeOffset.Now;
            var completed = false;
            try
            {
                ProgressText.Text = $"Checking - started {started:g}.";
                var progress = new Progress<DiagnosticObservation>(observation =>
                {
                    if (_cancellation != cancellation || cancellation.IsCancellationRequested) return;
                    _observations[observation.Checkpoint] = observation;
                    ObserveDiagram(observation);
                    ProgressText.Text = $"{Label(observation.Checkpoint)}: {observation.Detail}";
                    Render();
                });
                var traceProgress = new Progress<TraceHop>(hop =>
                {
                    if (_cancellation != cancellation || cancellation.IsCancellationRequested) return;
                    TracePanel.Children.Add(HopText(hop));
                    TraceStatus.Text = $"Observed hop {hop.Number} of at most 16: {hop.Observation.State}.";
                    ProgressText.Text = $"Traceroute hop {hop.Number}: {hop.Observation.Detail}";
                });
                _report = await _service.RunAsync(_network, wan, progress, cancellation.Token, traceProgress);
                foreach (var observation in _report.Observations)
                {
                    _observations[observation.Checkpoint] = observation;
                    ObserveDiagram(observation);
                }
                Render();
                if (cancellation.IsCancellationRequested)
                    _report = _report with { Cancelled = true };
                if (!_report.Cancelled)
                {
                    CompleteDiagramAnimation(_report);
                    completed = true;
                }
                TracePanel.Children.Clear();
                foreach (var hop in _report.Hops)
                    TracePanel.Children.Add(HopText(hop));
                TraceStatus.Text = _report.Cancelled ? "Trace cancelled / incomplete."
                    : _report.TraceComplete ? "Destination reached. Unanswered earlier hops do not prove a broken link."
                    : "Incomplete trace: destination not reached within 16 hops. Filtering or routing may explain unanswered hops.";
                ProgressText.Text = $"{(_report.Cancelled ? "Cancelled / partial" : "Checks complete")} - started {started:g}; finished {DateTimeOffset.Now:g}.";
            }
            catch (Exception exception) when (exception is InvalidOperationException or System.Net.NetworkInformation.NetworkInformationException)
            {
                ProgressText.Text = $"Diagnostics failed: {exception.Message}";
                foreach (var observation in _observations.Values.ToArray())
                    if (observation.State is DiagnosticState.Untested or DiagnosticState.Running)
                        _observations[observation.Checkpoint] = observation with { State = DiagnosticState.Error, Detail = "Run stopped by a diagnostic error." };
                _report = new(_observations.Values.ToArray(), [], false, false);
            }
            finally
            {
                if (!completed) StopDiagramAnimation();
                _cancellation = null;
                cancellation.Dispose();
                SetRunning(false);
                Render();
            }
        }
    }

    private static TextBlock HopText(TraceHop hop) => new()
    {
        Text = $"Hop {hop.Number}: {NetworkDiagnosticFormatter.Describe(hop.Observation)}",
        TextWrapping = TextWrapping.Wrap
    };

    private void SetRunning(bool running)
    {
        RunButton.IsEnabled = !running;
        UpdateAnimationCancelButton();
        AdapterPicker.IsEnabled = !running;
        RefreshButton.IsEnabled = !running;
        WanInput.IsEnabled = !running;
        RunProgress.IsActive = running;
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        StopDiagramAnimation();
        if (_cancellation is null) return;
        _cancellation?.Cancel();
        CancelRunButton.IsEnabled = false;
        ProgressText.Text = "Cancelling; waiting for probes to stop safely...";
    }

    private void BackButton_Click(object sender, RoutedEventArgs e) => BackRequested?.Invoke(this, EventArgs.Empty);

    private void Render()
    {
        if (SummaryBanner is null) return;
        _diagramPorts.Clear();
        DiagnosticsPanel.Children.Clear();
        foreach (var observation in _observations.Values)
        {
            var row = new TextBlock { Text = $"{Label(observation.Checkpoint)} - {NetworkDiagnosticFormatter.Describe(observation)}", TextWrapping = TextWrapping.Wrap };
            AutomationProperties.SetName(row, row.Text);
            DiagnosticsPanel.Children.Add(row);
        }
        Node(PcNode, "This PC", "\uE7F4", DiagnosticCheckpoint.Loopback, DiagnosticCheckpoint.LocalAddress);
        Node(RouterNode, "Home router", "\uE968", DiagnosticCheckpoint.Gateway, DiagnosticCheckpoint.RouterWan);
        Node(HopNode, "Upstream hop 2", "\uE968", DiagnosticCheckpoint.Hop2);
        Node(CloudflareNode, "Cloudflare", "\uEC06", DiagnosticCheckpoint.CloudflarePing, DiagnosticCheckpoint.CloudflareDns);
        Node(GoogleNode, "Google", "\uEC06", DiagnosticCheckpoint.GooglePing, DiagnosticCheckpoint.GoogleDns);
        var summary = _cancellation is not null
            ? new DiagnosticSummary(DiagnosticSummaryKind.Neutral, "Running / partial evidence", "Checks are in progress. Wait for completion before interpreting results, or cancel to stop.")
            : NetworkDiagnosticInterpreter.Summarize(_network, _report);
        SummaryTitle.Text = summary.Status;
        SummaryExplanation.Text = summary.Explanation;
        SummaryBanner.Background = StatusBrush(summary.Kind);
        SummaryTitle.Foreground = _accessibility.HighContrast || summary.Kind == DiagnosticSummaryKind.Neutral
            ? (Brush)Application.Current.Resources["TextFillColorPrimaryBrush"] : new SolidColorBrush(Microsoft.UI.Colors.White);
    }

    private void Node(StackPanel panel, string title, string glyph, params DiagnosticCheckpoint[] checkpoints)
    {
        panel.Children.Clear();
        panel.Spacing = 8;
        panel.Children.Add(new TextBlock { Text = title, TextAlignment = TextAlignment.Center, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
        var device = new Grid { ColumnSpacing = 4 };
        foreach (var width in new[] { new GridLength(1, GridUnitType.Star), new GridLength(14), new GridLength(44), new GridLength(14), new GridLength(1, GridUnitType.Star) })
        {
            device.ColumnDefinitions.Add(new ColumnDefinition { Width = width });
        }
        device.RowDefinitions.Add(new RowDefinition { Height = new GridLength(40) });
        device.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var icon = new FontIcon { Glyph = glyph, FontSize = 36 };
        Grid.SetColumn(icon, 2);
        device.Children.Add(icon);
        var portForeground = new SolidColorBrush(_accessibility.HighContrast
            ? _uiSettings.GetColorValue(UIColorType.Foreground)
            : ActualTheme == ElementTheme.Dark ? Microsoft.UI.Colors.White : Microsoft.UI.Colors.Black);
        for (var index = 0; index < checkpoints.Length; index++)
        {
            var checkpoint = checkpoints[index];
            if (!_observations.TryGetValue(checkpoint, out var observation)) continue;
            var kind = observation.State == DiagnosticState.Responded ? DiagnosticSummaryKind.Good
                : observation.State is DiagnosticState.Unanswered or DiagnosticState.Error ? DiagnosticSummaryKind.Problem : DiagnosticSummaryKind.Neutral;
            var address = NetworkDiagnosticFormatter.CheckpointAddress(observation);
            var marker = new Microsoft.UI.Xaml.Shapes.Ellipse
            {
                Width = 14, Height = 14, StrokeThickness = 2,
                Stroke = portForeground,
                Fill = kind == DiagnosticSummaryKind.Neutral ? null
                    : _accessibility.HighContrast ? portForeground : StatusBrush(kind),
                VerticalAlignment = VerticalAlignment.Center
            };
            AutomationProperties.SetName(marker, $"{Label(checkpoint)} port: {observation.State}");
            AutomationProperties.SetAutomationId(marker, $"DiagramPort{checkpoint}");
            _diagramPorts[checkpoint] = marker;
            var left = index == 0;
            var addressColumn = left ? 0 : 4;
            Grid.SetColumn(marker, left ? 1 : 3);
            device.Children.Add(marker);
            var addressText = new TextBlock
            {
                Text = address, FontSize = 11, VerticalAlignment = VerticalAlignment.Bottom,
                HorizontalAlignment = left ? HorizontalAlignment.Right : HorizontalAlignment.Left
            };
            AutomationProperties.SetAutomationId(addressText, $"DiagramAddress{checkpoint}");
            Grid.SetColumn(addressText, addressColumn);
            device.Children.Add(addressText);
            var description = new TextBlock
            {
                Text = $"{PortLabel(checkpoint)}\n{observation.State}",
                TextWrapping = TextWrapping.Wrap, FontSize = 11,
                TextAlignment = left ? TextAlignment.Right : TextAlignment.Left
            };
            AutomationProperties.SetAutomationId(description, $"DiagramCheckpoint{checkpoint}");
            ToolTipService.SetToolTip(marker, NetworkDiagnosticFormatter.Describe(observation));
            ToolTipService.SetToolTip(addressText, NetworkDiagnosticFormatter.Describe(observation));
            AutomationProperties.SetName(description, $"{Label(checkpoint)}: {address}; {observation.State}");
            Grid.SetRow(description, 1);
            Grid.SetColumn(description, addressColumn);
            device.Children.Add(description);
        }
        panel.Children.Add(device);
    }

    private Brush StatusBrush(DiagnosticSummaryKind kind)
    {
        if (_accessibility.HighContrast || kind == DiagnosticSummaryKind.Neutral)
            return (Brush)Application.Current.Resources["CardBackgroundFillColorDefaultBrush"];
        return new SolidColorBrush(kind switch
        {
            DiagnosticSummaryKind.Good => Color.FromArgb(255, 22, 101, 52),
            DiagnosticSummaryKind.Warning => Color.FromArgb(255, 154, 77, 0),
            _ => Color.FromArgb(255, 185, 28, 28)
        });
    }

    private static string PortLabel(DiagnosticCheckpoint checkpoint) => checkpoint switch
    {
        DiagnosticCheckpoint.Loopback => "Loopback",
        DiagnosticCheckpoint.LocalAddress => "LAN IP",
        DiagnosticCheckpoint.Gateway => "LAN IP",
        DiagnosticCheckpoint.RouterWan => "WAN IP",
        DiagnosticCheckpoint.CloudflarePing or DiagnosticCheckpoint.GooglePing => "IP ping",
        DiagnosticCheckpoint.CloudflareDns or DiagnosticCheckpoint.GoogleDns => "DNS",
        _ => "Hop-2 response"
    };

    private static string Label(DiagnosticCheckpoint checkpoint) => checkpoint switch
    {
        DiagnosticCheckpoint.Loopback => "Loopback",
        DiagnosticCheckpoint.LocalAddress => "This PC LAN IPv4",
        DiagnosticCheckpoint.Gateway => "Default gateway LAN IPv4",
        DiagnosticCheckpoint.RouterWan => "Optional router WAN IPv4",
        DiagnosticCheckpoint.Hop2 => "Observed hop 2",
        DiagnosticCheckpoint.CloudflarePing => "Cloudflare IP ping",
        DiagnosticCheckpoint.GooglePing => "Google IP ping",
        DiagnosticCheckpoint.ConfiguredDns => "Windows configured DNS",
        DiagnosticCheckpoint.CloudflareDns => "Direct Cloudflare DNS",
        _ => "Direct Google DNS"
    };
}
